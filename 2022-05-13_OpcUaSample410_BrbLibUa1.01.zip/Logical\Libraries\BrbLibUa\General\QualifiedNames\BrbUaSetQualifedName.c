#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

/* Besetzt einen QualifiedName */
plcdword BrbUaSetQualifedName(BrUaQualifiedName* pQualifiedName, unsigned short nNamespaceIndex, plcstring* pName)
{
	DWORD nStatus = 0x80460000; // = Bad_StructureMissing
	if(pQualifiedName != 0 && pName != 0)
	{
		nStatus = 0x00000000; // = Good
		pQualifiedName->NamespaceIndex = nNamespaceIndex;
		strncpy(pQualifiedName->Name, pName, sizeof(pQualifiedName->Name)-1);
	}
	return nStatus;
}
