#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

/* Gibt eine Liste mit Attribut-Texten zur�ck */
plcdword BrbUaGetAttributeList(struct UANodeInfo* pNodeInfo, struct BrbUaNodeInfoAttributes_TYP* pAttributes)
{
	DWORD nStatus = 0x80460000; // = Bad_StructureMissing
	if(pAttributes != 0)
	{
		memset(pAttributes, 0, sizeof(BrbUaNodeInfoAttributes_TYP));
		strcat(pAttributes->Attribute[UAAI_Default].sName, "Default");
		strcat(pAttributes->Attribute[UAAI_NodeId].sName, "NodeId");
		strcat(pAttributes->Attribute[UAAI_NodeClass].sName, "NodeClass");
		strcat(pAttributes->Attribute[UAAI_BrowseName].sName, "BrowseName");
		strcat(pAttributes->Attribute[UAAI_DisplayName].sName, "DisplayName");
		strcat(pAttributes->Attribute[UAAI_Description].sName, "Description");
		strcat(pAttributes->Attribute[UAAI_WriteMask].sName, "WriteMask");
		strcat(pAttributes->Attribute[UAAI_UserWriteMask].sName, "UserWriteMask");
		strcat(pAttributes->Attribute[UAAI_IsAbstract].sName, "IsAbstract");
		strcat(pAttributes->Attribute[UAAI_Symmetric].sName, "Symmetric");
		strcat(pAttributes->Attribute[UAAI_InverseName].sName, "InverseName");
		strcat(pAttributes->Attribute[UAAI_ContainsNoLoops].sName, "ContainsNoLoops");
		strcat(pAttributes->Attribute[UAAI_EventNotifier].sName, "EventNotifier");
		strcat(pAttributes->Attribute[UAAI_Value].sName, "Value");
		strcat(pAttributes->Attribute[UAAI_DataType].sName, "DataType");
		strcat(pAttributes->Attribute[UAAI_ValueRank].sName, "ValueRank");
		strcat(pAttributes->Attribute[UAAI_ArrayDimensions].sName, "ArrayDimensions");
		strcat(pAttributes->Attribute[UAAI_AccessLevel].sName, "AccessLevel");
		strcat(pAttributes->Attribute[UAAI_UserAccessLevel].sName, "UserAccessLevel");
		strcat(pAttributes->Attribute[UAAI_MinimumSamplingInterval].sName, "MinimumSamplingInterval");
		strcat(pAttributes->Attribute[UAAI_Historizing].sName, "Historizing");
		strcat(pAttributes->Attribute[UAAI_Executable].sName, "Executable");
		strcat(pAttributes->Attribute[UAAI_UserExecutable].sName, "UserExecutable");
		if(pNodeInfo != 0)
		{
			STRING sHelp[nBRBUA_VALUE_TEXT_CHAR_MAX];
			// Default bleibt leer
			BrbUaGetNodeIdText(&pNodeInfo->NodeID, pAttributes->Attribute[UAAI_NodeId].sValue);
			BrbUaGetNodeClassText(pNodeInfo->NodeClass, pAttributes->Attribute[UAAI_NodeClass].sValue);
			strcat(pAttributes->Attribute[UAAI_BrowseName].sValue, pNodeInfo->BrowseName);
			strcat(pAttributes->Attribute[UAAI_DisplayName].sValue, pNodeInfo->DisplayName.Text);
			strcat(pAttributes->Attribute[UAAI_Description].sValue, pNodeInfo->Description.Text);
			BrbUdintToAscii(pNodeInfo->WriteMask, pAttributes->Attribute[UAAI_WriteMask].sValue);
			BrbUdintToAscii(pNodeInfo->UserWriteMask, pAttributes->Attribute[UAAI_UserWriteMask].sValue);
			BrbUaGetBooleanText(pNodeInfo->IsAbstract, pAttributes->Attribute[UAAI_IsAbstract].sValue);
			BrbUaGetBooleanText(pNodeInfo->Symmetric, pAttributes->Attribute[UAAI_Symmetric].sValue);
			strcat(pAttributes->Attribute[UAAI_InverseName].sValue, pNodeInfo->InverseName);
			BrbUaGetBooleanText(pNodeInfo->ContainsNoLoops, pAttributes->Attribute[UAAI_ContainsNoLoops].sValue);
			BrbUaGetEventNotifierText(pNodeInfo->EventNotifier, pAttributes->Attribute[UAAI_EventNotifier].sValue);
			// Value bleibt leer
			UDINT nDatatypeId = BrbAsciiToUdint(pNodeInfo->DataType.Identifier);
			BrbUaGetDatatypeIdText(nDatatypeId, pAttributes->Attribute[UAAI_DataType].sValue);
			brsitoa((DINT)pNodeInfo->ValueRank, (UDINT)&sHelp);
			strcat(pAttributes->Attribute[UAAI_ValueRank].sValue, sHelp);
			BrbUaGetArrayDimensionText((UDINT*)&pNodeInfo->ArrayDimension, pNodeInfo->ValueRank, pAttributes->Attribute[UAAI_ArrayDimensions].sValue);
			BrbUaGetAccessLevelText(pNodeInfo->AccessLevel, pAttributes->Attribute[UAAI_AccessLevel].sValue);
			BrbUaGetAccessLevelText(pNodeInfo->UserAccessLevel, pAttributes->Attribute[UAAI_UserAccessLevel].sValue);
			BrbUdintToAscii((UDINT)pNodeInfo->MinimumSamplingInterval, sHelp);
			strcat(pAttributes->Attribute[UAAI_MinimumSamplingInterval].sValue, sHelp);
			BrbUaGetBooleanText(pNodeInfo->Historizing, pAttributes->Attribute[UAAI_Historizing].sValue);
			BrbUaGetBooleanText(pNodeInfo->Executable, pAttributes->Attribute[UAAI_Executable].sValue);
			BrbUaGetBooleanText(pNodeInfo->UserExecutable, pAttributes->Attribute[UAAI_UserExecutable].sValue);
			nStatus = 0x00000000; // = Good
		}
	}
	return nStatus;
}
