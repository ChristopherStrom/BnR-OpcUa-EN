
#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif
	
#include "BrbLib.h"

#ifdef __cplusplus
	};
#endif

/* Erkennt den �bergang einer bestimmten Position bei einer 360�-Rundachse */
plcbit BrbDetectAngleTransition(double rTransPosition, plcbit bDirection, double rPosAct, double rPosOld)
{
	BOOL bResult = 0;
	// Richtung feststellen
	LREAL rDir =  rPosAct - rPosOld;
	if(rPosAct >= 0.0 && rPosAct <= 90.0 && rPosOld >= 270.0 && rPosOld <= 360.0)
	{
		// �bergang von 360� auf 0�
		rDir = +1.0;
	}
	else if(rPosAct >= 270.0 && rPosAct <= 360.0 && rPosOld >= 0.0 && rPosOld <= 90.0)
	{
		// �bergang von 0� auf 360�
		rDir = -1.0;
	}
	if(rTransPosition <= 90.0)
	{
		// Positionen um 90� nach positiv verschieben, um �bergang von 360� auf 0� zu vermeiden
		rTransPosition = BrbNormalizeAngleDeg(rTransPosition + 90.0, 0);
		rPosAct = BrbNormalizeAngleDeg(rPosAct + 90.0, 0);
		rPosOld = BrbNormalizeAngleDeg(rPosOld + 90.0, 0);
	}
	else if(rTransPosition >= 270.0)
	{
		// Positionen um 90� nach negativ verschieben, um �bergang von 360� auf 0� zu vermeiden
		rTransPosition = BrbNormalizeAngleDeg(rTransPosition - 90.0, 0);
		rPosAct = BrbNormalizeAngleDeg(rPosAct - 90.0, 0);
		rPosOld = BrbNormalizeAngleDeg(rPosOld - 90.0, 0);
	}
	if(bDirection == 0 && rDir < 0.0)
	{
		// Negative Richtung
		if(rPosOld > rTransPosition && rPosAct <= rTransPosition)
		{
			bResult = 1;
		}
		else if(rPosOld >= rTransPosition && rPosAct < rTransPosition)
		{
			bResult = 1;
		}
	}
	else if(bDirection == 1 && rDir > 0.0)
	{
		// Positive Richtung
		if(rPosOld < rTransPosition && rPosAct >= rTransPosition)
		{
			bResult = 1;
		}
		else if(rPosOld <= rTransPosition && rPosAct > rTransPosition)
		{
			bResult = 1;
		}
	}
	return bResult;
}
