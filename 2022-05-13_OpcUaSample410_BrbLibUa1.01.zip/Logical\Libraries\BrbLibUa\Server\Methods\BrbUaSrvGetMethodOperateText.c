#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

/* Gibt den Text einer MethodOperateAction zur�ck */
plcdword BrbUaSrvGetMethodOperateText(enum UaMethodOperateAction eAction, plcstring* pActionText, unsigned long nActionTextSize)
{
	DWORD nStatus = 0x80460000; // = Bad_StructureMissing
	if(pActionText != 0)
	{
		nStatus = 0x00000000; // = Good
		memset(pActionText, 0, nActionTextSize);
		switch(eAction)
		{
			case UaMoa_CheckIsCalled:
				strcat(pActionText, "CheckIsCalled");
				break;	

			case UaMoa_Finished:
				strcat(pActionText, "Finished");
				break;	

		}
	}
	return nStatus;
}
