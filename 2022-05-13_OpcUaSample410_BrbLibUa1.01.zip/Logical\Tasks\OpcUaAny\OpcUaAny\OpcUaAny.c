#include <bur/plctypes.h>

#ifdef _DEFAULT_INCLUDES
	#include <AsDefault.h>
#endif

void _INIT Init(void)
{
	brsmemset((UDINT)&Data, 0, sizeof(Data));
}

void _CYCLIC Cyclic(void)
{
	// �ndern der Server-Daten, welche vom OpcUaAny-Client gelesen werden
	Data.Read.Server.nUsint += 1;
	Data.Read.Server.nUint += 1;
	Data.Read.Server.nUdint += 1;

	// �ndern der Client-Daten, welche auf den Server geschrieben werden
	Data.Write.Client.nUsint += 2;
	Data.Write.Client.nUint += 2;
	Data.Write.Client.nUdint += 2;
}

void _EXIT Exit(void)
{
}
