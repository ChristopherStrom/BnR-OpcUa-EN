#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

/* Gibt einen Verbindungs-Status als Text zur�ck */
plcdword BrbUaGetConnectionStatusText(enum UAConnectionStatus eConnectionStatus, plcstring* pStatusText, unsigned long nStatusTextSize)
{
	DWORD nStatus = 0x80460000; // = Bad_StructureMissing
	if(pStatusText != 0)
	{
		nStatus = 0x00000000; // = Good
		memset(pStatusText, 0, nStatusTextSize);
		switch(eConnectionStatus)
		{
			case UACS_Connected:
				strcat(pStatusText, "Connected");
				break;	

			case UACS_ConnectionError:
				strcat(pStatusText, "ConnectionError");
				break;	

			case UACS_Shutdown:
				strcat(pStatusText, "Shutdown");
				break;	
		}
	}
	return nStatus;
}
