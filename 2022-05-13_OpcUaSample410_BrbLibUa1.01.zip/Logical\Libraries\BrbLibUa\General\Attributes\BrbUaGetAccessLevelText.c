#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

/* Gibt den Text eines AccessLevels zur�ck */
plcdword BrbUaGetAccessLevelText(plcbyte nAccessLevel, plcstring* pText)
{
	DWORD nStatus = 0x80460000; // = Bad_StructureMissing
	if(pText != 0)
	{
		nStatus = 0x00000000; // = Good
		STRING sHelp[nBRBUA_VALUE_TEXT_CHAR_MAX];
		brsitoa((DINT)nAccessLevel, (UDINT)&sHelp);
		strcat(pText, sHelp);
		strcat(pText, "=");
		if(nAccessLevel == 0)
		{
			strcat(pText, "None");
		}
		else
		{
			if(BrbGetBitUsint(nAccessLevel, 0) == 1)
			{
				strcat(pText, " Read,");
			}
			if(BrbGetBitUsint(nAccessLevel, 1) == 1)
			{
				strcat(pText, " Write,");
			}
			if(BrbGetBitUsint(nAccessLevel, 2) == 1)
			{
				strcat(pText, " HistoryRead,");
			}
			if(BrbGetBitUsint(nAccessLevel, 3) == 1)
			{
				strcat(pText, " HistoryWrite,");
			}
			BrbStringTrimRight(pText, " ");
			BrbStringTrimLeft(pText, " ");
			BrbStringTrimRight(pText, ",");
		}
	}
	return nStatus;
}
