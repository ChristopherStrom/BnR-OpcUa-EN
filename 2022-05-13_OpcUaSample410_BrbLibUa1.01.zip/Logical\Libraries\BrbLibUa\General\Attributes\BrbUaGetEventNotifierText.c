#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

/* Gibt den Text eines EventNotifiers zur�ck */
plcdword BrbUaGetEventNotifierText(plcbyte nEventNotifier, plcstring* pText)
{
	DWORD nStatus = 0x80460000; // = Bad_StructureMissing
	if(pText != 0)
	{
		nStatus = 0x00000000; // = Good
		STRING sHelp[nBRBUA_VALUE_TEXT_CHAR_MAX];
		brsitoa((DINT)nEventNotifier, (UDINT)&sHelp);
		strcat(pText, sHelp);
		strcat(pText, "=");
		if(nEventNotifier == 0)
		{
			strcat(pText, "None");
		}
		else
		{
			if(BrbGetBitUsint(nEventNotifier, 0) == 1)
			{
				strcat(pText, " Subscribe,");
			}
			if(BrbGetBitUsint(nEventNotifier, 2) == 1)
			{
				strcat(pText, " HistoryRead,");
			}
			if(BrbGetBitUsint(nEventNotifier, 3) == 1)
			{
				strcat(pText, " HistoryWrite,");
			}
			BrbStringTrimRight(pText, " ");
			BrbStringTrimLeft(pText, " ");
			BrbStringTrimRight(pText, ",");
		}
	}
	return nStatus;
}
