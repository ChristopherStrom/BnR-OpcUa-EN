#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

/* Besetzt einen LocalizedText */
plcdword BrbUaSetLocalizedText(BrUaLocalizedText* pLocalizedText, plcstring* pLocale, plcstring* pText)
{
	DWORD nStatus = 0x80460000; // = Bad_StructureMissing
	if(pLocalizedText != 0 && pLocale != 0 && pText != 0)
	{
		nStatus = 0x00000000; // = Good
		strncpy(pLocalizedText->Locale, pLocale, sizeof(pLocalizedText->Locale)-1);
		strncpy(pLocalizedText->Text, pText, sizeof(pLocalizedText->Text)-1);
	}
	return nStatus;
}
