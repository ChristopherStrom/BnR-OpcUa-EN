
#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif
	#include "BrbLibUa.h"
#ifdef __cplusplus
	};
#endif

#include <string.h>

/* Erzeugt ein zuf�lliges XmlElement im Format '<Tag Attribute="X">Value</Tag>' */
plcdword BrbUaGetRandomXmlElement(BrUaXmlElement* pXmlElement)
{
	DWORD nStatus = 0x80460000; // = Bad_StructureMissing
	if(pXmlElement != 0)
	{
		nStatus = 0x00000000; // = Good
		strcpy((STRING*)&pXmlElement->Data, "<Tag Attribute=");
		strcat((STRING*)&pXmlElement->Data, (STRING*)&sBRB_QM);
		UDINT nNumber = (UDINT)BrbGetRandomDint(0, 255);
		STRING sNumber[12];
		brsitoa((DINT)nNumber, (UDINT)&sNumber);
		strcat((STRING*)&pXmlElement->Data, sNumber);
		strcat((STRING*)&pXmlElement->Data, (STRING*)&sBRB_QM);
		strcat((STRING*)&pXmlElement->Data, ">Value</Tag>");
		pXmlElement->Length = strlen((STRING*)&pXmlElement->Data);
	}
	return nStatus;
}
