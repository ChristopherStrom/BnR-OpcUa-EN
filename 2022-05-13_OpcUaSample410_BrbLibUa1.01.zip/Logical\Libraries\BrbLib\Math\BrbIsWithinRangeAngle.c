
#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLib.h"

#ifdef __cplusplus
	};
#endif

/* Gibt zur�ck, ob sich ein Winkel innerhalb eines Bereichs befindet */
plcbit BrbIsWithinRangeAngle(double rAngleAct, double rAngleStart, double rAngleEnd)
{
	BOOL bResult = 0;
	if(rAngleStart <= rAngleEnd)
	{
		if(rAngleAct >= rAngleStart && rAngleAct <= rAngleEnd)
		{
			bResult = 1;
		}
	}
	else
	{
		if(rAngleAct >= rAngleStart || rAngleAct <= rAngleEnd)
		{
			bResult = 1;
		}
	}
	return bResult;
}
