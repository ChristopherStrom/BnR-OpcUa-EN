#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

/* Gibt den Text eines boolschen Werts zur�ck */
plcdword BrbUaGetBooleanText(plcbit bBoolean, plcstring* pText)
{
	DWORD nStatus = 0x80460000; // = Bad_StructureMissing
	if(pText != 0)
	{
		nStatus = 0x00000000; // = Good
		if(bBoolean == 1)
		{
			strcat(pText, "True");
		}
		else
		{
			strcat(pText, "False");
		}
	}
	return nStatus;
}
