#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <AnsiCFunc.h>
#include <string.h>

#ifdef __cplusplus
	};
#endif

/* Wandelt einen Text in einen OpcUa-Value */
plcdword BrbUaConvVariantValueToString(struct UAVariantData* pUaVariantData, plcstring* pValueText, unsigned long nValueTextSize)
{
	DWORD nStatus = 0x80460000; // = Bad_StructureMissing
	if(pUaVariantData != 0 && pValueText != 0)
	{
		nStatus = 0x00000000; // = Good
		STRING sHelp[255];
		memset(pValueText, 0, nValueTextSize);
		switch(pUaVariantData->VariantType)
		{
			case UAVariantType_Null:
				strcpy(pValueText, "Null");
				break;

			case UAVariantType_Boolean:
				if(pUaVariantData->Boolean == 1)
				{
					strcpy(pValueText, "True");
				}
				else
				{
					strcpy(pValueText, "False");
				}
				break;

			case UAVariantType_SByte:
				brsitoa((DINT)pUaVariantData->SByte, (UDINT)pValueText);
				break;

			case UAVariantType_Byte:
				brsitoa((DINT)pUaVariantData->Byte, (UDINT)pValueText);
				break;

			case UAVariantType_Int16:
				brsitoa((DINT)pUaVariantData->Int16, (UDINT)pValueText);
				break;

			case UAVariantType_UInt16:
				brsitoa((DINT)pUaVariantData->UInt16, (UDINT)pValueText);
				break;

			case UAVariantType_Int32:
				brsitoa((DINT)pUaVariantData->Int32, (UDINT)pValueText);
				break;

			case UAVariantType_UInt32:
				BrbUdintToAscii(pUaVariantData->UInt32, pValueText);
				break;

			case UAVariantType_Int64:
				strcpy(pValueText, "Int64 not supported!");
				nStatus = 0x803D0000; // = Bad_NotSupported
				break;

			case UAVariantType_UInt64:
				strcpy(pValueText, "UInt64 not supported!");
				nStatus = 0x803D0000; // = Bad_NotSupported
				break;

			case UAVariantType_Float:
				brsftoa(pUaVariantData->Float, (UDINT)pValueText);
				break;

			case UAVariantType_Double:
				// Es gibt (noch) keine Umwandlungsfunktion von LREAL auf STRING
				// Deshalb wird zuerst in einen REAL gewandelt
				brsftoa((REAL)pUaVariantData->Double, (UDINT)pValueText);
				break;

			case UAVariantType_String:
				strncpy(pValueText, pUaVariantData->String, nValueTextSize);
				break;

			case UAVariantType_DateTime:
				BrbGetTimeTextDt(pUaVariantData->DateTime, pValueText, nValueTextSize, sBRBUA_TIMESTAMP_FORMAT);
				break;

			case UAVariantType_Guid:
				strcpy(pValueText, "Conversion of GUID not supported!");
				nStatus = 0x803D0000; // = Bad_NotSupported
				break;

			case UAVariantType_ByteString:
				strcpy(pValueText, "Conversion of ByteString not supported!");
				nStatus = 0x803D0000; // = Bad_NotSupported
				break;

			case UAVariantType_XmlElement:
				strcpy(pValueText, "Conversion of XmlElement not supported!");
				nStatus = 0x803D0000; // = Bad_NotSupported
				break;

			case UAVariantType_NodeId:
				if(pUaVariantData->NodeId.IdentifierType == UAIdentifierType_String)
				{
					strcpy(pValueText, "ns=");
					brsitoa((DINT)pUaVariantData->NodeId.NamespaceIndex, (UDINT)&sHelp);
					strcat(pValueText, sHelp);
					strcat(pValueText, ";s=");
					strcat(pValueText, pUaVariantData->NodeId.Identifier);
				}
				else if(pUaVariantData->NodeId.IdentifierType == UAIdentifierType_Numeric)
				{
					strcpy(pValueText, "ns=");
					brsitoa((DINT)pUaVariantData->NodeId.NamespaceIndex, (UDINT)&sHelp);
					strcat(pValueText, sHelp);
					strcat(pValueText, ";i=");
					strcat(pValueText, pUaVariantData->NodeId.Identifier);
				}
				else if(pUaVariantData->NodeId.IdentifierType == UAIdentifierType_GUID)
				{
					strcpy(pValueText, "Conversion of GUID node id not supported!");
					nStatus = 0x803D0000; // = Bad_NotSupported
				}
				else if(pUaVariantData->NodeId.IdentifierType == UAIdentifierType_Opaque)
				{
					strcpy(pValueText, "Conversion of opaque node id not supported!");
					nStatus = 0x803D0000; // = Bad_NotSupported
				}
				break;

			case UAVariantType_ExpandedNodeId:
				strcpy(pValueText, "Conversion of expanded node id not supported!");
				nStatus = 0x803D0000; // = Bad_NotSupported
				break;

			case UAVariantType_StatusCode:
				BrbUaGetStatusCodeText(pUaVariantData->UInt32, pValueText, nValueTextSize);
				break;

			case UAVariantType_QualifiedName:
				brsitoa((DINT)pUaVariantData->QualifiedName.NamespaceIndex, (UDINT)pValueText);
				strcat(pValueText, ":");
				strcat(pValueText, pUaVariantData->QualifiedName.Name);
				break;

			case UAVariantType_LocalizedText:
				if(strlen(pUaVariantData->LocalizedText.Locale) > 0)
				{
					strncpy(pValueText, pUaVariantData->LocalizedText.Locale, nValueTextSize);
					strncat(pValueText, ":", nValueTextSize);
					strncat(pValueText, pUaVariantData->LocalizedText.Text, nValueTextSize);
				}
				else
				{
					strncpy(pValueText, pUaVariantData->LocalizedText.Text, nValueTextSize);
				}
				break;

		}
	}
	return nStatus;
}
