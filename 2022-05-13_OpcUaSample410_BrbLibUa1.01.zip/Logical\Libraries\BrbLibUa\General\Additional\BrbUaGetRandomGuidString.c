#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

/* Erzeugt einen zuf�lligen GuidString im Format '01234567-0123-0123-0123-0123456789AB' */
plcdword BrbUaGetRandomGuidString(BrUaGuidString* pGuidString)
{
	DWORD nStatus = 0x80460000; // = Bad_StructureMissing
	if(pGuidString != 0)
	{
		nStatus = 0x00000000; // = Good
		memset(pGuidString, 0, sizeof(BrUaGuidString));
		STRING sSelection[64];
		strcpy(sSelection, "0123456789abcdef");
		STRING sGuidStringElement[13];
		BrbGetRandomStringExt(sGuidStringElement, sizeof(sGuidStringElement), 8, sSelection);
		strcat((STRING*)pGuidString, sGuidStringElement);
		strcat((STRING*)pGuidString, "-");
		BrbGetRandomStringExt(sGuidStringElement, sizeof(sGuidStringElement), 4, sSelection);
		strcat((STRING*)pGuidString, sGuidStringElement);
		strcat((STRING*)pGuidString, "-");
		BrbGetRandomStringExt(sGuidStringElement, sizeof(sGuidStringElement), 4, sSelection);
		strcat((STRING*)pGuidString, sGuidStringElement);
		strcat((STRING*)pGuidString, "-");
		BrbGetRandomStringExt(sGuidStringElement, sizeof(sGuidStringElement), 4, sSelection);
		strcat((STRING*)pGuidString, sGuidStringElement);
		strcat((STRING*)pGuidString, "-");
		BrbGetRandomStringExt(sGuidStringElement, sizeof(sGuidStringElement), 12, sSelection);
		strcat((STRING*)pGuidString, sGuidStringElement);
	}
	return nStatus;
}
