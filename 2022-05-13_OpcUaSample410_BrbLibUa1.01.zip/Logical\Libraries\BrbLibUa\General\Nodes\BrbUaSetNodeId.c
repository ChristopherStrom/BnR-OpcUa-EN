#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

/* Besetzt eine textuelle NodeId */
plcdword BrbUaSetNodeId(struct UANodeID* pNodeId, plcstring* sIdentifier, unsigned short nNamespaceIndex)
{
	DWORD nStatus = 0x80460000; // = Bad_StructureMissing
	if(pNodeId != 0)
	{
		nStatus = 0x00000000; // = Good
		strcpy(pNodeId->Identifier, sIdentifier);
		pNodeId->NamespaceIndex = nNamespaceIndex;
		if(BrbStringIsNumerical(sIdentifier) == 1)
		{
			pNodeId->IdentifierType = UAIdentifierType_Numeric;
		}
		else
		{
			pNodeId->IdentifierType = UAIdentifierType_String;
		}
	}
	return nStatus;
}
