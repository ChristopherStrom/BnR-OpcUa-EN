#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

/* Gibt den Text f�r eine ArrayDimension zur�ck */
plcdword BrbUaGetArrayDimensionText(unsigned long* pArrayDimension, signed long nValueRank, plcstring* pText)
{
	DWORD nStatus = 0x80460000; // = Bad_StructureMissing
	if(pText != 0)
	{
		nStatus = 0x800F0000; // = Bad_NothingToDo
		if(nValueRank > 0)
		{
			nStatus = 0x00000000; // = Good
			DINT nIndex = 0;
			STRING sHelp[nBRBUA_VALUE_TEXT_CHAR_MAX];
			if(nValueRank > (DINT)MAX_ELEMENTS_ARRAYDIMENSION)
			{
				nValueRank = MAX_ELEMENTS_ARRAYDIMENSION;
			}
			for(nIndex=0; nIndex<=nValueRank-1; nIndex++)
			{
				UDINT* pDim = ((UDINT*)pArrayDimension) + nIndex;
				BrbUdintToAscii(*pDim, sHelp);
				strcat(pText, sHelp);
				strcat(pText, ";");
			}
			BrbStringTrimRight(pText, ";");
		}
	}
	return nStatus;
}
