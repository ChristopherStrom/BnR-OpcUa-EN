#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <AnsiCFunc.h>
#include <string.h>

#ifdef __cplusplus
	};
#endif

/* H�ngt den Element-Namen eines OpcUa-Values anhand des Datentypen an einen Text an */
plcdword BrbUaAddVariantValueSubName(enum UAVariantType eVariantType, plcstring* pText)
{
	DWORD nStatus = 0x80460000; // = Bad_StructureMissing
	if(pText != 0)
	{
		nStatus = 0x00000000; // = Good
		switch(eVariantType)
		{
			case UAVariantType_Null:
				// Not supported
				nStatus = 0x803D0000; // = Bad_NotSupported
				break;

			case UAVariantType_Boolean:
				strcat(pText, ".Boolean");
				break;

			case UAVariantType_SByte:
				strcat(pText, ".SByte");
				break;

			case UAVariantType_Byte:
				strcat(pText, ".Byte");
				break;

			case UAVariantType_Int16:
				strcat(pText, ".Int16");
				break;

			case UAVariantType_UInt16:
				strcat(pText, ".UInt16");
				break;

			case UAVariantType_Int32:
				strcat(pText, ".Int32");
				break;

			case UAVariantType_UInt32:
				strcat(pText, ".UInt32");
				break;

			case UAVariantType_Int64:
				strcat(pText, ".Int64");
				break;

			case UAVariantType_UInt64:
				strcat(pText, ".UInt64");
				break;

			case UAVariantType_Float:
				strcat(pText, ".Float");
				break;

			case UAVariantType_Double:
				strcat(pText, ".Double");
				break;

			case UAVariantType_String:
				strcat(pText, ".String");
				break;

			case UAVariantType_DateTime:
				strcat(pText, ".DateTime");
				break;

			case UAVariantType_Guid:
				strcat(pText, ".String");
				break;

			case UAVariantType_ByteString:
				strcat(pText, ".String");
				break;

			case UAVariantType_XmlElement:
				// Not supported
				nStatus = 0x803D0000; // = Bad_NotSupported
				break;

			case UAVariantType_NodeId:
				strcat(pText, ".NodeId");
				break;

			case UAVariantType_ExpandedNodeId:
				strcat(pText, ".ExpandedNodeId");
				break;

			case UAVariantType_StatusCode:
				strcat(pText, ".StatusCode");
				break;

			case UAVariantType_QualifiedName:
				strcat(pText, ".QualifiedName");
				break;

			case UAVariantType_LocalizedText:
				strcat(pText, ".LocalizedText");
				break;

		}
	}
	return nStatus;
}
