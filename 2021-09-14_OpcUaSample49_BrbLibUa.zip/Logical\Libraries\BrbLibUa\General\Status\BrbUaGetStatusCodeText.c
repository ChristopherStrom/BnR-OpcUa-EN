#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <AnsiCFunc.h>
#include <string.h>

#ifdef __cplusplus
	};
#endif

/* Gibt den symbolischen Text f�r einen Ua-Status-Code zur�ck */
plcdword BrbUaGetStatusCodeText(unsigned long nStatusCode, plcstring* pStatusText, unsigned long nStatusTextSize)
{
	DWORD nStatus = 0x80460000; // = Bad_StructureMissing
	if(pStatusText != 0)
	{
		nStatus = 0x00000000; // = Good
		memset(pStatusText, 0, nStatusTextSize);
		BrbUdintToHex(nStatusCode, pStatusText, nStatusTextSize, 1);
		switch(nStatusCode)
		{
			case 0:
				strcat(pStatusText, " = Good");
				break;
			case 0x002D0000:
				strcat(pStatusText, " = Good_SubscriptionTransferred");
				break;
			case 0x002E0000:
				strcat(pStatusText, " = Good_CompletesAsynchronously");
				break;
			case 0x002F0000:
				strcat(pStatusText, " = Good_Overload");
				break;
			case 0x00300000:
				strcat(pStatusText, " = Good_Clamped");
				break;
			case 0x00960000:
				strcat(pStatusText, " = Good_LocalOverride");
				break;
			case 0x00A20000 :
				strcat(pStatusText, " = Good_EntryInserted");
				break;
			case 0x00A30000:
				strcat(pStatusText, " = Good_EntryReplaced");
				break;
			case 0x00A50000:
				strcat(pStatusText, " = Good_NoData");
				break;
			case 0x00A60000:
				strcat(pStatusText, " = Good_MoreData");
				break;
			case 0x00A70000:
				strcat(pStatusText, " = Good_CommunicationEvent");
				break;
			case 0x00A80000:
				strcat(pStatusText, " = Good_ShutdownEvent");
				break;
			case 0x00A90000:
				strcat(pStatusText, " = Good_CallAgain");
				break;
			case 0x00AA0000:
				strcat(pStatusText, " = Good_NonCriticalTimeout");
				break;
			case 0x00BA0000:
				strcat(pStatusText, " = Good_ResultsMayBeIncomplete");
				break;
			case 0x00D90000:
				strcat(pStatusText, " = Good_DataIgnored");
				break;
		
		
			case 0x406C0000:
				strcat(pStatusText, " = Uncertain_ReferenceOutOfServer");
				break;
			case 0x408F0000:
				strcat(pStatusText, " = Uncertain_NoCommunicationLastUsableValue");
				break;
			case 0x40900000:
				strcat(pStatusText, " = Uncertain_LastUsableValue");
				break;
			case 0x40910000:
				strcat(pStatusText, " = Uncertain_SubstituteValue");
				break;
			case 0x40920000:
				strcat(pStatusText, " = Uncertain_InitialValue");
				break;
			case 0x40930000:
				strcat(pStatusText, " = Uncertain_SensorNotAccurate");
				break;
			case 0x40940000:
				strcat(pStatusText, " = Uncertain_EngineeringUnitsExceeded");
				break;
			case 0x40950000:
				strcat(pStatusText, " = Uncertain_SubNormal");
				break;
			case 0x40A40000:
				strcat(pStatusText, " = Uncertain_DataSubNormal");
				break;
			case 0x40BC0000:
				strcat(pStatusText, " = Uncertain_ReferenceNotDeleted");
				break;
			case 0x40C00000:
				strcat(pStatusText, " = Uncertain_NotAllNodesAvailable");
				break;

		
			case 0x80000000:
				strcat(pStatusText, " = Bad");
				break;
			case 0x80010000:
				strcat(pStatusText, " = Bad_UnexpectedError");
				break;
			case 0x80020000:
				strcat(pStatusText, " = Bad_InternalError");
				break;
			case 0x80030000:
				strcat(pStatusText, " = Bad_OutOfMemory");
				break;
			case 0x80040000:
				strcat(pStatusText, " = Bad_ResourceUnavailable");
				break;
			case 0x80050000:
				strcat(pStatusText, " = Bad_CommunicationError");
				break;
			case 0x80060000:
				strcat(pStatusText, " = Bad_EncodingError");
				break;
			case 0x80070000:
				strcat(pStatusText, " = Bad_DecodingError");
				break;
			case 0x80080000:
				strcat(pStatusText, " = Bad_EncodingLimitsExceeded");
				break;
			case 0x80090000:
				strcat(pStatusText, " = Bad_UnknownResponse");
				break;
			case 0x800A0000:
				strcat(pStatusText, " = Bad_Timeout");
				break;
			case 0x800B0000:
				strcat(pStatusText, " = Bad_ServiceUnsupported");
				break;
			case 0x800C0000:
				strcat(pStatusText, " = Bad_Shutdown");
				break;
			case 0x800D0000:
				strcat(pStatusText, " = Bad_ServerNotConnected");
				break;
			case 0x800E0000:
				strcat(pStatusText, " = Bad_ServerHalted");
				break;
			case 0x800F0000:
				strcat(pStatusText, " = Bad_NothingToDo");
				break;
			case 0x80100000:
				strcat(pStatusText, " = Bad_TooManyOperations");
				break;
			case 0x80110000:
				strcat(pStatusText, " = Bad_DataTypeIdUnknown");
				break;
			case 0x80120000:
				strcat(pStatusText, " = Bad_CertificateInvalid");
				break;
			case 0x80130000:
				strcat(pStatusText, " = Bad_SecurityChecksFailed");
				break;
			case 0x80140000:
				strcat(pStatusText, " = Bad_CertificateTimeInvalid");
				break;
			case 0x80150000:
				strcat(pStatusText, " = Bad_CertificateIssuerTimeInvalid");
				break;
			case 0x80160000:
				strcat(pStatusText, " = Bad_CertificateHostNameInvalid");
				break;
			case 0x80170000:
				strcat(pStatusText, " = Bad_CertificateUriInvalid");
				break;
			case 0x80180000:
				strcat(pStatusText, " = Bad_CertificateUseNotAllowed");
				break;
			case 0x80190000:
				strcat(pStatusText, " = Bad_CertificateIssuerUseNotAllowed");
				break;
			case 0x801A0000:
				strcat(pStatusText, " = Bad_CertificateUntrusted");
				break;
			case 0x801B0000:
				strcat(pStatusText, " = Bad_CertificateRevocationUnknown");
				break;
			case 0x801C0000:
				strcat(pStatusText, " = Bad_CertificateIssuerRevocationUnknown");
				break;
			case 0x801D0000:
				strcat(pStatusText, " = Bad_CertificateRevoked");
				break;
			case 0x801E0000:
				strcat(pStatusText, " = Bad_CertificateIssuerRevoked");
				break;
			case 0x801F0000:
				strcat(pStatusText, " = Bad_UserAccessDenied");
				break;
			case 0x80200000:
				strcat(pStatusText, " = Bad_IdentityTokenInvalid");
				break;
			case 0x80210000:
				strcat(pStatusText, " = Bad_IdentityTokenRejected");
				break;
			case 0x80220000:
				strcat(pStatusText, " = Bad_SecureChannelIdInvalid");
				break;
			case 0x80230000:
				strcat(pStatusText, " = Bad_InvalidTimestamp");
				break;
			case 0x80240000:
				strcat(pStatusText, " = Bad_NonceInvalid");
				break;
			case 0x80250000:
				strcat(pStatusText, " = Bad_SessionIdInvalid");
				break;
			case 0x80260000:
				strcat(pStatusText, " = Bad_SessionClosed");
				break;
			case 0x80270000:
				strcat(pStatusText, " = Bad_SessionNotActivated");
				break;
			case 0x80280000:
				strcat(pStatusText, " = Bad_SubscriptionIdInvalid");
				break;
			case 0x802A0000:
				strcat(pStatusText, " = Bad_RequestHeaderInvalid");
				break;
			case 0x802B0000:
				strcat(pStatusText, " = Bad_TimestampsToReturnInvalid");
				break;
			case 0x802C0000:
				strcat(pStatusText, " = Bad_RequestCancelledByClient");
				break;
			case 0x80310000:
				strcat(pStatusText, " = Bad_NoCommunication");
				break;
			case 0x80320000:
				strcat(pStatusText, " = Bad_WaitingForInitialData");
				break;
			case 0x80330000:
				strcat(pStatusText, " = Bad_NodeIdInvalid");
				break;
			case 0x80340000:
				strcat(pStatusText, " = Bad_NodeIdUnknown");
				break;
			case 0x80350000:
				strcat(pStatusText, " = Bad_AttributeIdInvalid");
				break;
			case 0x80360000:
				strcat(pStatusText, " = Bad_IndexRangeInvalid");
				break;
			case 0x80370000:
				strcat(pStatusText, " = Bad_IndexRangeNoData");
				break;
			case 0x80380000:
				strcat(pStatusText, " = Bad_DataEncodingInvalid");
				break;
			case 0x80390000:
				strcat(pStatusText, " = Bad_DataEncodingUnsupported");
				break;
			case 0x803A0000:
				strcat(pStatusText, " = Bad_NotReadable");
				break;
			case 0x803B0000:
				strcat(pStatusText, " = Bad_NotWritable");
				break;
			case 0x803C0000:
				strcat(pStatusText, " = Bad_OutOfRange");
				break;
			case 0x803D0000:
				strcat(pStatusText, " = Bad_NotSupported");
				break;
			case 0x803E0000:
				strcat(pStatusText, " = Bad_NotFound");
				break;
			case 0x803F0000:
				strcat(pStatusText, " = Bad_ObjectDeleted");
				break;
			case 0x80400000:
				strcat(pStatusText, " = Bad_NotImplemented");
				break;
			case 0x80410000:
				strcat(pStatusText, " = Bad_MonitoringModeInvalid");
				break;
			case 0x80420000:
				strcat(pStatusText, " = Bad_MonitoredItemIdInvalid");
				break;
			case 0x80430000:
				strcat(pStatusText, " = Bad_MonitoredItemFilterInvalid");
				break;
			case 0x80440000:
				strcat(pStatusText, " = Bad_MonitoredItemFilterUnsupported");
				break;
			case 0x80450000:
				strcat(pStatusText, " = Bad_FilterNotAllowed");
				break;
			case 0x80460000:
				strcat(pStatusText, " = Bad_StructureMissing");
				break;
			case 0x80470000:
				strcat(pStatusText, " = Bad_EventFilterInvalid");
				break;
			case 0x80480000:
				strcat(pStatusText, " = Bad_ContentFilterInvalid");
				break;
			case 0x80490000:
				strcat(pStatusText, " = Bad_FilterOperandInvalid");
				break;
			case 0x804A0000:
				strcat(pStatusText, " = Bad_ContinuationPointInvalid");
				break;
			case 0x804B0000:
				strcat(pStatusText, " = Bad_NoContinuationPoints");
				break;
			case 0x804C0000:
				strcat(pStatusText, " = Bad_ReferenceTypeIdInvalid");
				break;
			case 0x804D0000:
				strcat(pStatusText, " = Bad_BrowseDirectionInvalid");
				break;
			case 0x804E0000:
				strcat(pStatusText, " = Bad_NodeNotInView");
				break;
			case 0x804F0000:
				strcat(pStatusText, " = Bad_ServerUriInvalid");
				break;
			case 0x80500000:
				strcat(pStatusText, " = Bad_ServerNameMissing");
				break;
			case 0x80510000:
				strcat(pStatusText, " = Bad_DiscoveryUrlMissing");
				break;
			case 0x80520000:
				strcat(pStatusText, " = Bad_SempahoreFileMissing");
				break;
			case 0x80530000:
				strcat(pStatusText, " = Bad_RequestTypeInvalid");
				break;
			case 0x80540000:
				strcat(pStatusText, " = Bad_SecurityModeRejected");
				break;
			case 0x80550000:
				strcat(pStatusText, " = Bad_SecurityPolicyRejected");
				break;
			case 0x80560000:
				strcat(pStatusText, " = Bad_TooManySessions");
				break;
			case 0x80570000:
				strcat(pStatusText, " = Bad_UserSignatureInvalid");
				break;
			case 0x80580000:
				strcat(pStatusText, " = Bad_ApplicationSignatureInvalid");
				break;
			case 0x80590000:
				strcat(pStatusText, " = Bad_NoValidCertificates");
				break;
			case 0x805A0000:
				strcat(pStatusText, " = Bad_RequestCancelledByRequest");
				break;
			case 0x805B0000:
				strcat(pStatusText, " = Bad_ParentNodeIdInvalid");
				break;
			case 0x805C0000:
				strcat(pStatusText, " = Bad_ReferenceNotAllowed");
				break;
			case 0x805D0000:
				strcat(pStatusText, " = Bad_NodeIdRejected");
				break;
			case 0x805E0000:
				strcat(pStatusText, " = Bad_NodeIdExists");
				break;
			case 0x805F0000:
				strcat(pStatusText, " = Bad_NodeClassInvalid");
				break;
			case 0x80600000:
				strcat(pStatusText, " = Bad_BrowseNameInvalid");
				break;
			case 0x80610000:
				strcat(pStatusText, " = Bad_BrowseNameDuplicated");
				break;
			case 0x80620000:
				strcat(pStatusText, " = Bad_NodeAttributesInvalid");
				break;
			case 0x80630000:
				strcat(pStatusText, " = Bad_TypeDefinitionInvalid");
				break;
			case 0x80640000:
				strcat(pStatusText, " = Bad_SourceNodeIdInvalid");
				break;
			case 0x80650000:
				strcat(pStatusText, " = Bad_TargetNodeIdInvalid");
				break;
			case 0x80660000:
				strcat(pStatusText, " = Bad_DuplicateReferenceNotAllowed");
				break;
			case 0x80670000:
				strcat(pStatusText, " = Bad_InvalidSelfReference");
				break;
			case 0x80680000:
				strcat(pStatusText, " = Bad_ReferenceLocalOnly");
				break;
			case 0x80690000:
				strcat(pStatusText, " = Bad_NoDeleteRights");
				break;
			case 0x806A0000:
				strcat(pStatusText, " = Bad_ServerIndexInvalid");
				break;
			case 0x806B0000:
				strcat(pStatusText, " = Bad_ViewIdUnknown");
				break;
			case 0x806D0000:
				strcat(pStatusText, " = Bad_TooManyMatches");
				break;
			case 0x806E0000:
				strcat(pStatusText, " = Bad_QueryTooComplex");
				break;
			case 0x806F0000:
				strcat(pStatusText, " = Bad_NoMatch");
				break;
			case 0x80700000:
				strcat(pStatusText, " = Bad_MaxAgeInvalid");
				break;
			case 0x80710000:
				strcat(pStatusText, " = Bad_HistoryOperationInvalid");
				break;
			case 0x80720000:
				strcat(pStatusText, " = Bad_HistoryOperationUnsupported");
				break;
			case 0x80730000:
				strcat(pStatusText, " = Bad_WriteNotSupported");
				break;
			case 0x80740000:
				strcat(pStatusText, " = Bad_TypeMismatch");
				break;
			case 0x80750000:
				strcat(pStatusText, " = Bad_MethodInvalid");
				break;
			case 0x80760000:
				strcat(pStatusText, " = Bad_ArgumentsMissing");
				break;
			case 0x80770000:
				strcat(pStatusText, " = Bad_TooManySubscriptions");
				break;
			case 0x80780000:
				strcat(pStatusText, " = Bad_TooManyPublishRequests");
				break;
			case 0x80790000:
				strcat(pStatusText, " = Bad_NoSubscription");
				break;
			case 0x807A0000:
				strcat(pStatusText, " = Bad_SequenceNumberUnknown");
				break;
			case 0x807B0000:
				strcat(pStatusText, " = Bad_MessageNotAvailable");
				break;
			case 0x807C0000:
				strcat(pStatusText, " = Bad_InsufficientClientProfile");
				break;
			case 0x807D0000:
				strcat(pStatusText, " = Bad_TcpServerTooBusy");
				break;
			case 0x807E0000:
				strcat(pStatusText, " = Bad_TcpMessageTypeInvalid");
				break;
			case 0x807F0000:
				strcat(pStatusText, " = Bad_TcpSecureChannelUnknown");
				break;
			case 0x80800000:
				strcat(pStatusText, " = Bad_TcpMessageTooLarge");
				break;
			case 0x80810000:
				strcat(pStatusText, " = Bad_TcpNotEnoughResources");
				break;
			case 0x80820000:
				strcat(pStatusText, " = Bad_TcpInternalError");
				break;
			case 0x80830000:
				strcat(pStatusText, " = Bad_TcpEndpointUrlInvalid");
				break;
			case 0x80840000:
				strcat(pStatusText, " = Bad_RequestInterrupted");
				break;
			case 0x80850000:
				strcat(pStatusText, " = Bad_RequestTimeout");
				break;
			case 0x80860000:
				strcat(pStatusText, " = Bad_SecureChannelClosed");
				break;
			case 0x80870000:
				strcat(pStatusText, " = Bad_SecureChannelTokenUnknown");
				break;
			case 0x80880000:
				strcat(pStatusText, " = Bad_SequenceNumberInvalid");
				break;
			case 0x80890000:
				strcat(pStatusText, " = Bad_ConfigurationError");
				break;
			case 0x808A0000:
				strcat(pStatusText, " = Bad_NotConnected");
				break;
			case 0x808B0000:
				strcat(pStatusText, " = Bad_DeviceFailure");
				break;
			case 0x808C0000:
				strcat(pStatusText, " = Bad_SensorFailure");
				break;
			case 0x808D0000:
				strcat(pStatusText, " = Bad_OutOfService");
				break;
			case 0x808E0000:
				strcat(pStatusText, " = Bad_DeadbandFilterInvalid");
				break;
			case 0x80970000:
				strcat(pStatusText, " = Bad_RefreshInProgress");
				break;
			case 0x80980000:
				strcat(pStatusText, " = Bad_ConditionAlreadyDisabled");
				break;
			case 0x80990000:
				strcat(pStatusText, " = Bad_ConditionDisabled");
				break;
			case 0x809A0000:
				strcat(pStatusText, " = Bad_EventIdUnknown");
				break;
			case 0x809B0000:
				strcat(pStatusText, " = Bad_NoData");
				break;
			case 0x809D0000:
				strcat(pStatusText, " = Bad_DataLost");
				break;
			case 0x809E0000:
				strcat(pStatusText, " = Bad_DataUnavailable");
				break;
			case 0x809F0000:
				strcat(pStatusText, " = Bad_EntryExists");
				break;
			case 0x80A00000:
				strcat(pStatusText, " = Bad_NoEntryExists");
				break;
			case 0x80A10000:
				strcat(pStatusText, " = Bad_TimestampNotSupported");
				break;
			case 0x80AB0000:
				strcat(pStatusText, " = Bad_InvalidArgument");
				break;
			case 0x80AC0000:
				strcat(pStatusText, " = Bad_ConnectionRejected");
				break;
			case 0x80AD0000:
				strcat(pStatusText, " = Bad_Disconnect");
				break;
			case 0x80AE0000:
				strcat(pStatusText, " = Bad_ConnectionClosed");
				break;
			case 0x80AF0000:
				strcat(pStatusText, " = Bad_InvalidState");
				break;
			case 0x80B00000:
				strcat(pStatusText, " = Bad_EndOfStream");
				break;
			case 0x80B10000:
				strcat(pStatusText, " = Bad_NoDataAvailable");
				break;
			case 0x80B20000:
				strcat(pStatusText, " = Bad_WaitingForResponse");
				break;
			case 0x80B30000:
				strcat(pStatusText, " = Bad_OperationAbandoned");
				break;
			case 0x80B40000:
				strcat(pStatusText, " = Bad_ExpectedStreamToBlock");
				break;
			case 0x80B50000:
				strcat(pStatusText, " = Bad_WouldBlock");
				break;
			case 0x80B60000:
				strcat(pStatusText, " = Bad_SyntaxError");
				break;
			case 0x80B70000:
				strcat(pStatusText, " = Bad_MaxConnectionsReached");
				break;
			case 0x80B80000:
				strcat(pStatusText, " = Bad_RequestTooLarge");
				break;
			case 0x80B90000:
				strcat(pStatusText, " = Bad_ResponseTooLarge");
				break;
			case 0x80BB0000:
				strcat(pStatusText, " = Bad_EventNotAcknowledgeable");
				break;
			case 0x80BD0000:
				strcat(pStatusText, " = Bad_InvalidTimestampArgument");
				break;
			case 0x80BE0000:
				strcat(pStatusText, " = Bad_ProtocolVersionUnsupported");
				break;
			case 0x80BF0000:
				strcat(pStatusText, " = Bad_StateNotActive");
				break;
			case 0x80C10000:
				strcat(pStatusText, " = Bad_FilterOperatorInvalid");
				break;
			case 0x80C20000:
				strcat(pStatusText, " = Bad_FilterOperatorUnsupported");
				break;
			case 0x80C30000:
				strcat(pStatusText, " = Bad_FilterOperandCountMismatch");
				break;
			case 0x80C40000:
				strcat(pStatusText, " = Bad_FilterElementInvalid");
				break;
			case 0x80C50000:
				strcat(pStatusText, " = Bad_FilterLiteralInvalid");
				break;
			case 0x80C60000:
				strcat(pStatusText, " = Bad_IdentityChangeNotSupported");
				break;
			case 0x80C80000:
				strcat(pStatusText, " = Bad_NotTypeDefinition");
				break;
			case 0x80C90000:
				strcat(pStatusText, " = Bad_ViewTimestampInvalid");
				break;
			case 0x80CA0000:
				strcat(pStatusText, " = Bad_ViewParameterMismatch");
				break;
			case 0x80CB0000:
				strcat(pStatusText, " = Bad_ViewVersionInvalid");
				break;
			case 0x80CC0000:
				strcat(pStatusText, " = Bad_ConditionAlreadyEnabled");
				break;
			case 0x80CD0000:
				strcat(pStatusText, " = Bad_DialogNotActive");
				break;
			case 0x80CE0000:
				strcat(pStatusText, " = Bad_DialogResponseInvalid");
				break;
			case 0x80CF0000:
				strcat(pStatusText, " = Bad_ConditionBranchAlreadyAcked");
				break;
			case 0x80D00000:
				strcat(pStatusText, " = Bad_ConditionBranchAlreadyConfirmed");
				break;
			case 0x80D10000:
				strcat(pStatusText, " = Bad_ConditionAlreadyShelved");
				break;
			case 0x80D20000:
				strcat(pStatusText, " = Bad_ConditionNotShelved");
				break;
			case 0x80D30000:
				strcat(pStatusText, " = Bad_ShelvingTimeOutOfRange");
				break;
			case 0x80D40000:
				strcat(pStatusText, " = Bad_AggregateListMismatch");
				break;
			case 0x80D50000:
				strcat(pStatusText, " = Bad_AggregateNotSupported");
				break;
			case 0x80D60000:
				strcat(pStatusText, " = Bad_AggregateInvalidInputs");
				break;
			case 0x80D70000:
				strcat(pStatusText, " = Bad_BoundNotFound");
				break;
			case 0x80D80000:
				strcat(pStatusText, " = Bad_BoundNotSupported");
				break;
			case 0x80DA0000:
				strcat(pStatusText, " = Bad_AggregateConfigurationRejected");
				break;
			case 0x80DB0000:
				strcat(pStatusText, " = Bad_TooManyMonitoredItems");
				break;


			case 0x81010000:
				strcat(pStatusText, " = Bad_SignatureInvalid");
				break;
			case 0x81040000:
				strcat(pStatusText, " = Bad_ExtensibleParameterInvalid");
				break;
			case 0x81050000:
				strcat(pStatusText, " = Bad_ExtensibleParameterUnsupported");
				break;
			case 0x81060000:
				strcat(pStatusText, " = Bad_HostUnknown");
				break;
			case 0x81070000:
				strcat(pStatusText, " = Bad_TooManyPosts");
				break;
			case 0x81080000:
				strcat(pStatusText, " = Bad_SecurityConfig");
				break;
			case 0x81090000:
				strcat(pStatusText, " = Bad_FileNotFound");
				break;
			case 0x810A0000:
				strcat(pStatusText, " = Bad_FileExists");
				break;
		
		
			case 0xA0010000:
				strcat(pStatusText, " = PlcOpen_BadFwPermanentError");
				break;
			case 0xA0020000:
				strcat(pStatusText, " = PlcOpen_BadFwTempError");
				break;
			case 0xA0030000:
				strcat(pStatusText, " = PlcOpen_BadConnectionError");
				break;
			case 0xA0040000:
				strcat(pStatusText, " = PlcOpen_BadHostNotFound");
				break;
			case 0xA0050000:
				strcat(pStatusText, " = PlcOpen_BadAlreadyConnected");
				break;
			case 0xA0060000:
				strcat(pStatusText, " = PlcOpen_BadSecurityFailed");
				break;
			case 0xA0070000:
				strcat(pStatusText, " = PlcOpen_BadSuspended");
				break;
			case 0xA0080000:
				strcat(pStatusText, " = PlcOpen_BadConnectionInvalidHdl");
				break;
			case 0xA0090000:
				strcat(pStatusText, " = PlcOpen_BadNsNotFound");
				break;
			case 0xA00A0000:
				strcat(pStatusText, " = PlcOpen_BadResultTooLong");
				break;
			case 0xA00B0000:
				strcat(pStatusText, " = PlcOpen_BadInvalidType");
				break;
			case 0xA00C0000:
				strcat(pStatusText, " = PlcOpen_BadNodeInvalidHdl");
				break;
			case 0xA00D0000:
				strcat(pStatusText, " = PlcOpen_BadMethodInvalidHdl");
				break;
			case 0xA00E0000:
				strcat(pStatusText, " = PlcOpen_BadReadFailed");
				break;
			case 0xA00F0000:
				strcat(pStatusText, " = PlcOpen_BadWriteFailed");
				break;
			case 0xA0100000:
				strcat(pStatusText, " = PlcOpen_BadCallFailed");
				break;
			case 0xA0110000:
				strcat(pStatusText, " = PlcOpen_BadInParamFailed");
				break;
			case 0xA0120000:
				strcat(pStatusText, " = PlcOpen_BadOutParamFailed");
				break;
			case 0xA0130000:
				strcat(pStatusText, " = PlcOpen_BadSubscriptionInvalidHdl");
				break;
			case 0xA0140000:
				strcat(pStatusText, " = PlcOpen_BadMonitoredItemInvalidHdl");
				break;
			case 0xA0150000:
				strcat(pStatusText, " = PlcOpen_BadMonitoredItemSyncMismatch");
				break;


			case 0xB0020000:
				strcat(pStatusText, " = PlcOpen_BadUnexpectedNoOfResults");
				break;
			case 0xB0030000:
				strcat(pStatusText, " = PlcOpen_BadIndexOutOfRange");
				break;
			case 0xB0040000:
				strcat(pStatusText, " = PlcOpen_BadVariableNameInvalid");
				break;
			case 0xB0050000:
				strcat(pStatusText, " = PlcOpen_BadTypeNameInvalid");
				break;
			case 0xB0060000:
				strcat(pStatusText, " = PlcOpen_BadBrowseNameNotFound");
				break;
			case 0xB0070000:
				strcat(pStatusText, " = PlcOpen_BadConfigAmbiguity");
				break;
			case 0xB0080000:
				strcat(pStatusText, " = PlcOpen_BadEventFieldSelection");
				break;
			case 0xB0090000:
				strcat(pStatusText, " = PlcOpen_BadEventContentFilter");
				break;
			case 0xB00C0000:
				strcat(pStatusText, " = PlcOpen_BadElementCount");
				break;
			case 0xB00D0000:
				strcat(pStatusText, " = PlcOpen_BadMonitoringQueueSize");
				break;
			case 0xB00E0000:
				strcat(pStatusText, " = PlcOpen_BadServerNotRunning");
				break;
			case 0xB00F0000:
				strcat(pStatusText, " = PlcOpen_BadNodeIdAlreayUsed");
				break;
			case 0xB0100000:
				strcat(pStatusText, " = PlcOpen_BadMethodCallHandleInvalid");
				break;
			case 0xB0110000:
				strcat(pStatusText, " = PlcOpen_BadMethodNameInvalid");
				break;
			case 0xB0190000:
				strcat(pStatusText, " = PlcOpen_BadInvalidEventFieldValue");
				break;
		
			case 0xB00B0000:
				strcat(pStatusText, " = Bad_InvalidNodeCount");
				break;
			case 0xB0120000:
				strcat(pStatusText, " = Bad_NoAuthorization");
				break;
			case 0xB0130000:
				strcat(pStatusText, " = Bad_UnknownRole");
				break;
			case 0xB0140000:
				strcat(pStatusText, " = Bad_UnknownAccessRight");
				break;
			case 0xB0150000:
				strcat(pStatusText, " = Bad_NoRoles");
				break;
			case 0xB0160000:
				strcat(pStatusText, " = Bad_TooManyRoles");
				break;
			case 0xB0170000:
				strcat(pStatusText, " = Bad_DuplicateRole");
				break;
			case 0xB0180000:
				strcat(pStatusText, " = Bad_InvisibleNode");
				break;
			
			default:
				nStatus = 0x803D0000; // Bad_NotSupported
				break;
			
		}
	}
	return nStatus;
}
