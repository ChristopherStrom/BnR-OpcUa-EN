#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

/* Gibt zur�ck, ob zwei NodeIds gleich sind */
plcbit BrbUaAreNodeIdsEqual(struct UANodeID* pNodeId1, struct UANodeID* pNodeId2)
{
	return (memcmp(pNodeId1, pNodeId2, sizeof(UANodeID)) == 0);
}
