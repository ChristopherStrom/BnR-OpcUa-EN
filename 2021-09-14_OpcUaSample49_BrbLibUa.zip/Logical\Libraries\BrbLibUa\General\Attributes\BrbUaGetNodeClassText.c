#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

/* Gibt den Text einer NodeClass zur�ck */
plcdword BrbUaGetNodeClassText(enum UANodeClass eNodeClass, plcstring* pText)
{
	DWORD nStatus = 0x80460000; // = Bad_StructureMissing
	if(pText != 0)
	{
		nStatus = 0x00000000; // = Good
		switch(eNodeClass)
		{
			case UANodeClass_None:
				strcat(pText, "None");
				break;

			case UANodeClass_Object:
				strcat(pText, "Object");
				break;

			case UANodeClass_Variable:
				strcat(pText, "Variable");
				break;

			case UANodeClass_Method:
				strcat(pText, "Method");
				break;

			case UANodeClass_ObjectType:
				strcat(pText, "ObjectType");
				break;

			case UANodeClass_VariableType:
				strcat(pText, "VariableType");
				break;

			case UANodeClass_ReferenceType:
				strcat(pText, "ReferenceType");
				break;

			case UANodeClass_DataType:
				strcat(pText, "DataType");
				break;

			case UANodeClass_View:
				strcat(pText, "View");
				break;

			case UANodeClass_All:
				strcat(pText, "All");
				break;

			default:
				strcat(pText, "Unknown");
				break;

		}
	}
	return nStatus;
}
