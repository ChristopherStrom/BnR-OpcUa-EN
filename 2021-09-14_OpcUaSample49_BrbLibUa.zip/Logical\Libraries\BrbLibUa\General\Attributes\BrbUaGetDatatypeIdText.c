#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

/* Gibt den Text zu einem Datentyp-Identifier zur�ck */
plcdword BrbUaGetDatatypeIdText(unsigned long nDatatypeId, plcstring* pText)
{
	DWORD nStatus = 0x80460000; // = Bad_StructureMissing
	if(pText != 0)
	{
		nStatus = 0x00000000; // = Good
		if(nDatatypeId == 1)
		{
			strcat(pText, "1=Boolean");
		}
		else if(nDatatypeId == 2) 
		{
			strcat(pText, "2=SByte");
		}
		else if(nDatatypeId == 3) 
		{
			strcat(pText, "3=Byte");
		}
		else if(nDatatypeId == 4) 
		{
			strcat(pText, "4=Int16");
		}
		else if(nDatatypeId == 5) 
		{
			strcat(pText, "5=UInt16");
		}
		else if(nDatatypeId == 6) 
		{
			strcat(pText, "6=Int32");
		}
		else if(nDatatypeId == 7) 
		{
			strcat(pText, "7=UInt32");
		}
		else if(nDatatypeId == 8) 
		{
			strcat(pText, "8=Int64");
		}
		else if(nDatatypeId == 9) 
		{
			strcat(pText, "9=UInt64");
		}
		else if(nDatatypeId == 10) 
		{
			strcat(pText, "10=Float");
		}
		else if(nDatatypeId == 11) 
		{
			strcat(pText, "11=Double");
		}
		else if(nDatatypeId == 12) 
		{
			strcat(pText, "12=String");
		}
		else if(nDatatypeId == 13) 
		{
			strcat(pText, "13=DateTime");
		}
		else if(nDatatypeId == 14) 
		{
			strcat(pText, "14=Guid");
		}
		else if(nDatatypeId == 15) 
		{
			strcat(pText, "15=ByteString");
		}
		else if(nDatatypeId == 16) 
		{
			strcat(pText, "16=XmlElement");
		}
		else if(nDatatypeId == 17) 
		{
			strcat(pText, "17=NodeId");
		}
		else if(nDatatypeId == 18) 
		{
			strcat(pText, "18=ExpandedNodeId");
		}
		else if(nDatatypeId == 19) 
		{
			strcat(pText, "19=StatusCode");
		}
		else if(nDatatypeId == 20) 
		{
			strcat(pText, "20=QualifiedName");
		}
		else if(nDatatypeId == 21) 
		{
			strcat(pText, "21=LocalizedText");
		}
		else if(nDatatypeId == 22) 
		{
			strcat(pText, "22=Structure");
		}
		else if(nDatatypeId == 23) 
		{
			strcat(pText, "23=DataValue");
		}
		else if(nDatatypeId == 25) 
		{
			strcat(pText, "25=DiagnosticInfo");
		}
		else if(nDatatypeId == 26) 
		{
			strcat(pText, "26=Number");
		}
		else if(nDatatypeId == 29) 
		{
			strcat(pText, "29=Enumeration");
		}
		else if(nDatatypeId == 121) 
		{
			strcat(pText, "121=Decimal128");
		}
		else
		{
			STRING sHelp[nBRBUA_VALUE_TEXT_CHAR_MAX];
			BrbUdintToAscii(nDatatypeId, sHelp);
			strcat(pText, sHelp);
		}
	}
	return nStatus;
}
