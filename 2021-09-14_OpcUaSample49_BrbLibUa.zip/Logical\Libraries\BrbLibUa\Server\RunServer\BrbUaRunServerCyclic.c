#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>
#include <AnsiCFunc.h>

#ifdef __cplusplus
	};
#endif

// Eigene Enums und Typen
enum Steps_ENUM
{
	eSTEP_INIT,
	eSTEP_GET_NAMESPACE,
	eSTEP_GET_EVENT_NS,
	eSTEP_RUNNING,
};

/* Behandelt eine Server-Instanz */
void BrbUaRunServerCyclic(struct BrbUaRunServerCyclic* inst)
{
	switch(inst->eStep)
	{
		case eSTEP_INIT:
			// Fub initialisieren
			inst->nStatus = eBRB_ERR_OK;
			//memset(&inst->fbUaSrv_GetServerState, 0, sizeof(inst->fbUaSrv_GetServerState));
			// Server-Pointer pr�fen
			if(inst->pRunServer != 0)
			{
				inst->pRunServer->State.nErroId = 0;
				if(inst->pRunServer->State.eState == eBRB_RSSTATE_INIT_DONE)
				{
					inst->nNamespaceIndex = 0;
					inst->nEventIndex = 0;
					inst->eStep = eSTEP_GET_NAMESPACE;
				}
				else
				{
					inst->nStatus = eBRB_ERR_INVALID_PARAMETER;
					inst->pRunServer->State.nErroId = inst->nStatus;
					strcpy(inst->pRunServer->State.sErrorText, "Cyclic error: Init not done");
				}
			}
			else
			{
				inst->nStatus = eBRB_ERR_NULL_POINTER;
			}
			break;

		case eSTEP_GET_NAMESPACE:
			// NamespaceIndex ermitteln
			inst->pRunServer->State.eState = eBRB_RSSTATE_DETECTING;
			if(inst->pRunServer->Namespaces.nNamespaceCount > 0 && inst->pRunServer->Namespaces.pNamespaces != 0)
			{
				if(inst->nNamespaceIndex < inst->pRunServer->Namespaces.nNamespaceCount)
				{
					BrbUaRsNamespace_TYP* pNamespace = ((BrbUaRsNamespace_TYP*)inst->pRunServer->Namespaces.pNamespaces) + inst->nNamespaceIndex;
					inst->fbUaSrv_GetNamespaceIndex.Execute = 1;
					strcpy(inst->fbUaSrv_GetNamespaceIndex.NamespaceUri, pNamespace->sNamespaceUri);
					if(inst->fbUaSrv_GetNamespaceIndex.Done == 1)
					{
						inst->fbUaSrv_GetNamespaceIndex.Execute = 0;
						pNamespace->nNamespaceIndex = inst->fbUaSrv_GetNamespaceIndex.NamespaceIndex;
						pNamespace->nErrorId = 0x00000000; // = Good
						inst->nNamespaceIndex += 1;
					}
					else if(inst->fbUaSrv_GetNamespaceIndex.Error == 1)
					{
						inst->fbUaSrv_GetNamespaceIndex.Execute = 0;
						pNamespace->nNamespaceIndex = 0;
						pNamespace->nErrorId = inst->fbUaSrv_GetNamespaceIndex.ErrorID;
						inst->pRunServer->State.nErroId = inst->fbUaSrv_GetNamespaceIndex.ErrorID;
						strcpy(inst->pRunServer->State.sErrorText, "Cyclic error on getting Namespace#");
						STRING sHelp[16];
						brsitoa(inst->nNamespaceIndex, (UDINT)&sHelp);
						strcat(inst->pRunServer->State.sErrorText, sHelp);
						inst->nNamespaceIndex += 1;
					}
				}
				else
				{
					inst->eStep = eSTEP_GET_EVENT_NS;
				}
			}
			else
			{
				// Keine Namespaces: Andere Eintragungen mache keinen Sinn
				inst->eStep = eSTEP_RUNNING;
			}
			break;

		case eSTEP_GET_EVENT_NS:
			// Bei allen Events den ServerNamespaceIndex eintragen (in 64-Bl�cken)
			inst->pRunServer->State.eServerState = eBRB_RSSTATE_DETECTING;
			if(inst->pRunServer->Events.nEventCount > 0 && inst->pRunServer->Events.pEvents != 0)
			{
				DINT nRemainingItemsCount = inst->pRunServer->Events.nEventCount - inst->nEventIndex;
				if(nRemainingItemsCount > 0)
				{
					UINT nItemCount = nRemainingItemsCount;
					if(nRemainingItemsCount > 64)
					{
						nItemCount = 64;
					}
					for(inst->nLoopIndex=0; inst->nLoopIndex < nItemCount; inst->nLoopIndex++)
					{
						// ServerNamespaceIndex aus geparsten DatObj-Index f�r jedes Event ermitteln
						BrbUaRsEventIntern_TYP* pEvent = ((BrbUaRsEventIntern_TYP*)inst->pRunServer->Events.pEvents) + inst->nEventIndex + inst->nLoopIndex;
						pEvent->TypeNodeId.NamespaceIndex = BrbUaRsGetNamespace(inst->pRunServer, pEvent->nDatObjNamespaceIndex, 0);
					}
					inst->nEventIndex += nItemCount;
				}
				else
				{
					inst->nEventIndex = 0;
					inst->eStep = eSTEP_RUNNING;
				}
			}
			else
			{
				inst->eStep = eSTEP_RUNNING;
			}
			break;

		case eSTEP_RUNNING:
			inst->pRunServer->State.eState = eBRB_RSSTATE_RUNNING;
			// Server-Status abfragen
			inst->pRunServer->State.eServerState = UaSrv_GetServerState();
			break;

	}

	// Aufruf aller FB's
	UaSrv_GetNamespaceIndex(&inst->fbUaSrv_GetNamespaceIndex);
}
