#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

/* Gibt den Text einer NodeId zur�ck */
plcdword BrbUaGetNodeIdText(struct UANodeID* pNodeId, plcstring* pText)
{
	DWORD nStatus = 0x80460000; // = Bad_StructureMissing
	if(pNodeId != 0 && pText != 0)
	{
		nStatus = 0x00000000; // = Good
		STRING sHelp[nBRBUA_VALUE_TEXT_CHAR_MAX];
		strcat(pText, "ns=");
		brsitoa((DINT)pNodeId->NamespaceIndex, (UDINT)&sHelp);
		strcat(pText, sHelp);
		if(pNodeId->IdentifierType == UAIdentifierType_Numeric)
		{
			strcat(pText, ";i=");
		}
		else if(pNodeId->IdentifierType == UAIdentifierType_String)
		{
			strcat(pText, ";s=");
		}
		else if(pNodeId->IdentifierType == UAIdentifierType_GUID)
		{
			strcat(pText, ";g=");
		}
		else if(pNodeId->IdentifierType == UAIdentifierType_Opaque)
		{
			strcat(pText, ";o=");
		}
		else
		{
			strcat(pText, ";?=");
		}
		strcat(pText, pNodeId->Identifier);
	}
	return nStatus;
}
