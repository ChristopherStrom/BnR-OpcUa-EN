#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <string.h>

#ifdef __cplusplus
	};
#endif

/* Erzeugt einen zuf�lligen ByteString */
plcdword BrbUaGetRandomByteString(unsigned char* pData, signed long nLength)
{
	DWORD nStatus = 0x80460000; // = Bad_StructureMissing
	if(pData != 0)
	{
		nStatus = 0x803C0000; // = Bad_OutOfRange
		if(nLength > 0)
		{
			nStatus = 0x00000000; // = Good
			INT nIndex = 0;
			for(nIndex=0; nIndex<nLength; nIndex++)
			{
				*(pData + nIndex) = (USINT)BrbGetRandomDint(0, 255);
			}
		}
	}
	return nStatus;
}
