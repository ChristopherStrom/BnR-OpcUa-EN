#include <bur/plctypes.h>
#ifdef __cplusplus
	extern "C"
	{
#endif

#include "BrbLibUa.h"
#include <AnsiCFunc.h>
#include <string.h>

#ifdef __cplusplus
	};
#endif

/* Wandelt einen OpcUa-Value in einen Text */
plcdword BrbUaConvVariantValueFromString(struct UAVariantData* pUaVariantData, plcstring* pValueText)
{
	DWORD nStatus = 0x80460000; // = Bad_StructureMissing
	if(pUaVariantData != 0 && pValueText != 0)
	{
		nStatus = 0x00000000; // = Good
		switch(pUaVariantData->VariantType)
		{
			case UAVariantType_Null:
				// Not supported by library
				BrbUaClearVariantValue(pUaVariantData);
				nStatus = 0x803D0000; // = Bad_NotSupported
				break;

			case UAVariantType_Boolean:
				BrbUaClearVariantValue(pUaVariantData);
				if(strcmp(pValueText, "True") == 0 || strcmp(pValueText, "true") == 0 || strcmp(pValueText, "1") == 0)
				{
					pUaVariantData->Boolean = 1;
				}
				else
				{
					pUaVariantData->Boolean = 0;
				}
				break;

			case UAVariantType_SByte:
				BrbUaClearVariantValue(pUaVariantData);
				pUaVariantData->SByte = (SINT)brsatoi((UDINT)pValueText);
				break;

			case UAVariantType_Byte:
				BrbUaClearVariantValue(pUaVariantData);
				pUaVariantData->Byte = (USINT)brsatoi((UDINT)pValueText);
				break;

			case UAVariantType_Int16:
				BrbUaClearVariantValue(pUaVariantData);
				pUaVariantData->Int16 = (INT)brsatoi((UDINT)pValueText);
				break;

			case UAVariantType_UInt16:
				BrbUaClearVariantValue(pUaVariantData);
				pUaVariantData->UInt16 = (UINT)brsatoi((UDINT)pValueText);
				break;

			case UAVariantType_Int32:
				BrbUaClearVariantValue(pUaVariantData);
				pUaVariantData->Int32 = brsatoi((UDINT)pValueText);
				break;

			case UAVariantType_UInt32:
				BrbUaClearVariantValue(pUaVariantData);
				pUaVariantData->UInt32 = BrbAsciiToUdint(pValueText);
				break;

			case UAVariantType_Int64:
				// Not supported
				BrbUaClearVariantValue(pUaVariantData);
				nStatus = 0x803D0000; // = Bad_NotSupported
				break;

			case UAVariantType_UInt64:
				// Not supported
				BrbUaClearVariantValue(pUaVariantData);
				nStatus = 0x803D0000; // = Bad_NotSupported
				break;

			case UAVariantType_Float:
				BrbUaClearVariantValue(pUaVariantData);
				BrbStringReplace(pValueText, ",", ".");
				pUaVariantData->Float = brsatof((UDINT)pValueText);
				break;

			case UAVariantType_Double:
				// Es gibt (noch) keine Umwandlungsfunktion von STRING auf LREAL
				// Deshalb wird zuerst in einen REAL gewandelt
				BrbUaClearVariantValue(pUaVariantData);
				BrbStringReplace(pValueText, ",", ".");
				pUaVariantData->Double = (LREAL)brsatof((UDINT)pValueText);
				break;

			case UAVariantType_String:
				BrbUaClearVariantValue(pUaVariantData);
				strcpy((STRING*)&pUaVariantData->String, pValueText);
				break;

			case UAVariantType_DateTime:
				BrbUaClearVariantValue(pUaVariantData);
				pUaVariantData->DateTime = BrbGetDtFromTimeText(pValueText, sBRBUA_DATETIME_FORMAT);
				break;

			case UAVariantType_Guid:
				// Not supported by library
				BrbUaClearVariantValue(pUaVariantData);
				nStatus = 0x803D0000; // = Bad_NotSupported
				break;

			case UAVariantType_ByteString:
				// Not supported by library
				BrbUaClearVariantValue(pUaVariantData);
				nStatus = 0x803D0000; // = Bad_NotSupported
				break;

			case UAVariantType_XmlElement:
				// Not supported by library
				BrbUaClearVariantValue(pUaVariantData);
				nStatus = 0x803D0000; // = Bad_NotSupported
				break;

			case UAVariantType_NodeId:
				BrbUaClearVariantValue(pUaVariantData);
				pUaVariantData->NodeId.NamespaceIndex = 0;
				UDINT nTextLen = brsstrlen((UDINT)pValueText);
				DINT nEndCharIndex = 0;
				if(BrbStringStartsWith(pValueText, "ns=") == 1)
				{
					nEndCharIndex = BrbStringGetIndexOf(pValueText, ";", nTextLen);
					if(nEndCharIndex == -1)
					{
						// Keine Id, nur NamespaceIndex
						nEndCharIndex = nTextLen;
					}
					if(nEndCharIndex > 3)
					{
						STRING sNamespaceIndex[32];
						BrbStringGetSubText((STRING*)pValueText, 3, nEndCharIndex-3, sNamespaceIndex);
						pUaVariantData->NodeId.NamespaceIndex = (UINT)brsatoi((UDINT)&sNamespaceIndex);
					}
				}
				nEndCharIndex = BrbStringGetIndexOf(pValueText, "i=", nTextLen);
				break;

			case UAVariantType_ExpandedNodeId:
				// Not supported by library
				BrbUaClearVariantValue(pUaVariantData);
				nStatus = 0x803D0000; // = Bad_NotSupported
				break;

			case UAVariantType_StatusCode:
				// Not supported by library
				BrbUaClearVariantValue(pUaVariantData);
				nStatus = 0x803D0000; // = Bad_NotSupported
				break;

			case UAVariantType_QualifiedName:
				// Not supported by library
				BrbUaClearVariantValue(pUaVariantData);
				nStatus = 0x803D0000; // = Bad_NotSupported
				break;

			case UAVariantType_LocalizedText:
				// Not supported by library
				BrbUaClearVariantValue(pUaVariantData);
				nStatus = 0x803D0000; // = Bad_NotSupported
				break;

		}
	}
	return nStatus;
}
